% Author: Kenji Kashima
% Date  : 2023/09/28
% Note  : system identification

function [err_a, err_b,TrSigma,p_est ,y] ...
    = sysid_module(p_star ,n ,q0 ,u ,v ,p0 ,Sigma0 ,beta)
% args: p_star -- the TRUE system parameters [a1,a2,...,a_n,b1,b2,...,b_m]
%       n      -- the number of a  (m denotes the number of b)
%       q0     -- initial data [y_n,...,y_0,u_m,...,u_0]
%       u      -- u_data
%       v      -- v_data
%       p0     -- initial parameters 
%       Sigma0 -- initial Sigma in Algorithm 3
%       beta   -- forgetting factor

[dim_p, N] = size(p_star); % dim_p = m + n  % N denote the length of the data series
y = zeros(1,N-1);  
q = zeros(dim_p,N);
q(:,1) = q0;

% open loop control to genereate y data
for k = 1:N-1
    y(k) =  p_star(:,k)' * q(:,k)+ v(k);
    q(:,k+1) =[y(k);q(1:n-1,k);u(k+1);q(n+1:dim_p-1,k)];
end

p_est = zeros(dim_p,N);
err_a = zeros(1,N);
err_b = zeros(1,N);
TrSigma = zeros(1,N);

p_est(:,1) = p0; 
Sigma = Sigma0;

% sum of the squares between the true parameters and the estimated parameters
err_a(1) = norm(p_star(1:n,1)-p0(1:n))^2;
err_b(1) = norm(p_star(n+1:dim_p,1)-p0(n+1:dim_p))^2;
TrSigma(1) = trace(Sigma);

for k=1:N-1
    % Algorithm 3:
    H = Sigma*q(:,k) / (beta + q(:,k)'*Sigma*q(:,k)); %line 3
    p_est(:,k+1) = p_est(:,k)+H*(y(k)-p_est(:,k)'*q(:,k)); %line 4
    Sigma = (Sigma - H*q(:,k)'*Sigma)/beta; %line 5
 
    % for figure 8.3 (c)~(f)
    err_a(k+1) = norm(p_star(1:n,k+1)-p_est(1:n,k+1))^2;
    err_b(k+1) = norm(p_star(n+1:dim_p,k+1)-p_est(n+1:dim_p,k+1))^2;
    TrSigma(k+1) = trace(Sigma); % trace of Sigma
end


